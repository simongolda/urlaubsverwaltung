package org.synyx.urlaubsverwaltung.application.application;

public class EditApplicationForLeaveNotAllowedException extends RuntimeException {

    EditApplicationForLeaveNotAllowedException(String message) {
        super(message);
    }
}
