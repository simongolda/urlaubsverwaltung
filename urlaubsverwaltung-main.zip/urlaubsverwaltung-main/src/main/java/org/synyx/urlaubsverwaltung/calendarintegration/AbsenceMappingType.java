package org.synyx.urlaubsverwaltung.calendarintegration;

public enum AbsenceMappingType {

    VACATION,
    SICKNOTE
}
