package org.synyx.urlaubsverwaltung.api;

public final class RestApiDateFormat {

    public static final String DATE_PATTERN = "yyyy-MM-dd";

    private RestApiDateFormat() {
        // Hide constructor for util classes
    }
}
