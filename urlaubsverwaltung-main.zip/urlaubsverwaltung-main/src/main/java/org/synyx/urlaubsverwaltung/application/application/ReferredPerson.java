package org.synyx.urlaubsverwaltung.application.application;

/**
 * Represents the person that should decide about an application for leave.
 */
public class ReferredPerson {

    private String username;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
