package org.synyx.urlaubsverwaltung.calendar;

public class CalendarException extends RuntimeException {

    CalendarException(String message, Throwable cause) {
        super(message, cause);
    }
}
