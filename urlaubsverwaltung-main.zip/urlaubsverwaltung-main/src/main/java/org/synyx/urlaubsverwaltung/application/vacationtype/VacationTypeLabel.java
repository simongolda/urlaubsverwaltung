package org.synyx.urlaubsverwaltung.application.vacationtype;

import java.util.Locale;

public record VacationTypeLabel(Locale locale, String label) {
}
