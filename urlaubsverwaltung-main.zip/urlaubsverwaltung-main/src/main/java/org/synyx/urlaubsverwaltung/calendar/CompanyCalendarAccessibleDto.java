package org.synyx.urlaubsverwaltung.calendar;

public class CompanyCalendarAccessibleDto {

    private boolean accessible;

    public boolean isAccessible() {
        return accessible;
    }

    public void setAccessible(boolean accessible) {
        this.accessible = accessible;
    }
}
