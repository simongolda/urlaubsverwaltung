package org.synyx.urlaubsverwaltung.calendar;

public enum ICalType {

    PUBLISHED,
    CANCELLED
}
