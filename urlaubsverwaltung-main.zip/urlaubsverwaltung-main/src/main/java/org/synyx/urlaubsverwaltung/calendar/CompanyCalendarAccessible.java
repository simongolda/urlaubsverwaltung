package org.synyx.urlaubsverwaltung.calendar;

import jakarta.persistence.Entity;

@Entity
public class CompanyCalendarAccessible extends CalendarAccessible {
}
