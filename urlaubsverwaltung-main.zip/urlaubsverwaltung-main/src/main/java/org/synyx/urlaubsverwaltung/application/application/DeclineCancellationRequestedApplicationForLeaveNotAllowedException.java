package org.synyx.urlaubsverwaltung.application.application;

public class DeclineCancellationRequestedApplicationForLeaveNotAllowedException extends RuntimeException {

    DeclineCancellationRequestedApplicationForLeaveNotAllowedException(String message) {
        super(message);
    }
}
