package org.synyx.urlaubsverwaltung.application.vacationtype;

public record VacationTypeDto(
    Long id,
    VacationTypeColor color
) {
}
